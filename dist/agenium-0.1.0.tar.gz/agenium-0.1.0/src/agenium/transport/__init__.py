"""Transport layer (HTTP/2 + mTLS)."""
