"""Persistence layer (SQLite sessions, outbox)."""
